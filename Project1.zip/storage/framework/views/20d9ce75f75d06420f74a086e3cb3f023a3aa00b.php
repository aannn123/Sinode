<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">

                        
                        <div class="card-header">
                            <div class="col-sm-12 col-md-6">
                                <h3>Data Tidak Memenuhi Syarat</h3>
                            </div>
                        </div>

                        
                        <div class="card-body">
                            <form action="<?php echo e(route('tidakMemenuhi')); ?>" method="GET">
                                <?php echo csrf_field(); ?>
                                <div class="form-row">
                                    <div class="col-6">
                                        <select class="form-control" name="gereja">
                                            <option selected disabled>--PILIH GEREJA--</option>

                                            <?php $__currentLoopData = $gereja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                    <div class="col-2">
                                        <input type="date" class="form-control" name="from">
                                    </div>
                                    <p>TO</p>
                                    <div class="col-2">
                                        <input type="date" class="form-control" name="to">
                                    </div>
                                </div>

                                <div>
                                    <button type="submit" class="btn btn-primary float-right">Confirm</button>
                                </div>

                            </form>
                        </div>

                        
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped" id="table">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Gereja</th>
                                            <th>Nomor Telepon</th>
                                            <th>Alamat</th>
                                            <th>Acrion</th>
                                        </tr>
                                    </thead>
                                    

                                    <tbody>
                                        <?php
                                            $no = 1;
                                        ?>
                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($no++); ?></td>
                                                <td><?php echo e($item->fullname); ?></td>
                                                <td><?php echo e($item->church_name); ?></td>
                                                <td><?php echo e($item->phone_number); ?></td>
                                                <td><?php echo e($item->address); ?></td>
                                                <td>View</td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                    

                                </table>
                            </div>
                            
                            <div class="row d-flex justify-content-between">

                                <div class="ml-3">
                                    <a href="<?php echo e(route('export.failed')); ?>" class="btn btn-success btn-sm"
                                      >Export</a>
                                </div>

                                <div class="ml-3">
                                    <a href="<?php echo e(route('export.all')); ?>" class="btn btn-primary btn-sm"
                                      >Export Semua Data</a>
                                </div>
                               
                                <div class="mr-2">
                                    <?php echo e($items->links()); ?>


                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Project/Project1/resources/views/pages/form/tidakMemenuhiSyarat.blade.php ENDPATH**/ ?>