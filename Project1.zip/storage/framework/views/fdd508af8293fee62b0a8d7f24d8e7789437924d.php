<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/view.css')); ?>">
    
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@1,200;1,300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
        integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body>
    <div class="row">
        <div class="col-md-3 display-left">
            <?php echo $__env->make('layouts.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>  
        <div class="col-md-9" style="padding-top:30px;padding-left:20px;">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    <div class="col-md-12 d-flex align-items-center justify-content-center" style="background-color: #001420;height:60px">
        <b style="color: white">&copy; <?php echo e(date('Y')); ?> Copyright Sinode Gereja Kristus</b>
    </div>


    </div>
    <script src="<?php echo e(asset('assets/js/jquery-1.12.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/cannot-back.js')); ?>"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php echo $__env->yieldPushContent('js'); ?>
</body>

</html>
<?php /**PATH /var/www/html/Project/Project1/resources/views/layouts/user/default.blade.php ENDPATH**/ ?>