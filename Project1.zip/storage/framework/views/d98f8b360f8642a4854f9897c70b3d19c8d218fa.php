<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div style="background-color: #f4f6f9">

                        <div class="section-header">
                            <h1>Dashboard</h1>
                        </div>
                        <div class="row">

                            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                <div class="card card-statistic-1">
                                    <div class="card-icon bg-primary" style="background: #35A5DD">
                                        <i class="fas fa-users"></i>
                                    </div>

                                    <div class="card-wrap">
                                        <div class="card-header">
                                            <h4>Total Survey</h4>
                                        </div>
                                    </div>

                                    <div class="card-body">
                                        <?php echo e($all); ?>

                                    </div>
                                </div>
                            </div>


                            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                <div class="card card-statistic-1">
                                    <div class="card-icon bg-success" style="background: #35A5DD">
                                        <i class="fas fa-user-check"></i>
                                    </div>

                                    <div class="card-wrap">
                                        <div class="card-header">
                                            <h4>Memenuhi Syarat</h4>
                                        </div>
                                    </div>

                                    <div class="card-body">
                                        <?php echo e($success); ?>

                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                <div class="card card-statistic-1">
                                    <div class="card-icon bg-danger" style="background: #35A5DD">
                                        <i class="fas fa-user-times"></i>
                                    </div>

                                    <div class="card-wrap">
                                        <div class="card-header">
                                            <h4>Tidak Memenuhi Syarat</h4>
                                        </div>
                                    </div>

                                    <div class="card-body">
                                        <?php echo e($failed); ?>

                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4>Data Statistik Survey</h4>
                                    </div>
                                    <div class="card-body">
                                        <canvas id="myChart" height="158"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        var ctx = document.getElementById("myChart").getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September",
                    "Oktober", "November", "Desember"
                ],
                datasets: [{
                        label: 'Total Survey',
                        data: [<?php echo e($month['jan']); ?>, <?php echo e($month['feb']); ?>, <?php echo e($month['mar']); ?>,
                            <?php echo e($month['apr']); ?>, <?php echo e($month['mei']); ?>, <?php echo e($month['jun']); ?>,
                            <?php echo e($month['jul']); ?>, <?php echo e($month['ags']); ?>, <?php echo e($month['sep']); ?>,
                            <?php echo e($month['okt']); ?>, <?php echo e($month['nov']); ?>, <?php echo e($month['des']); ?>

                        ],
                        borderWidth: 2,
                        backgroundColor: '#6777ef',
                        borderColor: '#6777ef',
                        borderWidth: 2.5,
                        pointBackgroundColor: '#ffffff',
                        pointRadius: 4
                    },
                    {
                        label: 'Berhasil',
                        data: [<?php echo e($succ['jan']); ?>, <?php echo e($succ['feb']); ?>, <?php echo e($succ['mar']); ?>,
                            <?php echo e($succ['apr']); ?>, <?php echo e($succ['mei']); ?>, <?php echo e($succ['jun']); ?>,
                            <?php echo e($succ['jul']); ?>, <?php echo e($succ['ags']); ?>, <?php echo e($succ['sep']); ?>,
                            <?php echo e($succ['okt']); ?>, <?php echo e($succ['nov']); ?>, <?php echo e($succ['des']); ?>

                        ],
                        borderWidth: 2,
                        backgroundColor: '#47c363',
                        borderColor: '#47c363',
                        borderWidth: 2.5,
                        pointBackgroundColor: '#ffffff',
                        pointRadius: 4
                    },
                    {
                        label: 'Gagal',
                        data: [<?php echo e($fail['jan']); ?>, <?php echo e($fail['feb']); ?>, <?php echo e($fail['mar']); ?>,
                            <?php echo e($fail['apr']); ?>, <?php echo e($fail['mei']); ?>, <?php echo e($fail['jun']); ?>,
                            <?php echo e($fail['jul']); ?>, <?php echo e($fail['ags']); ?>, <?php echo e($fail['sep']); ?>,
                            <?php echo e($fail['okt']); ?>, <?php echo e($fail['nov']); ?>, <?php echo e($fail['des']); ?>

                        ],
                        borderWidth: 2,
                        backgroundColor: '#fc544b',
                        borderColor: '#fc544b',
                        borderWidth: 2.5,
                        pointBackgroundColor: '#ffffff',
                        pointRadius: 4
                    }
                ]
            },
            options: {
                legend: {
                    display: false
                },
                scales: {
                    yAxes: [{
                        gridLines: {
                            drawBorder: false,
                            color: '#f2f2f2',
                        },
                        ticks: {
                            beginAtZero: true,
                            stepSize: 150
                        }
                    }],
                    xAxes: [{
                        ticks: {
                            display: false
                        },
                        gridLines: {
                            display: false
                        }
                    }]
                },
            }
        });

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Project/Project1/resources/views/admin/index.blade.php ENDPATH**/ ?>