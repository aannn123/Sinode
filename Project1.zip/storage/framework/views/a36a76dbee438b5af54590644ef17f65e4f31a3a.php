
<img src="<?php echo e(asset('assets/img/logo.png')); ?>" style="width:90%" alt="">
<div class="mt-3">
    <b style="font-size: 18px;font-weight:bolder">Form Pendaftaran Ibadah Onsite
        Sinode Gereja Kristus</b><br>

    <div class="mb-2 mt-2">
        <h5 style="color:white;">Petunjuk :</h5>
    </div>
    <p class="text-hint">1. Berdoa minta pertolongan Tuhan sebelum memutuskan ikut ibadah Onsite.</p>
    <p class="text-hint">2. Pendaftaran setiap <b>hari Senin pk. 08.00 s/d Jumat pk. 12.00</b></p>
    <p class="text-hint">3. Isilah <b>data pernyataan</b> dengan Jujur dan benar.</p>
    <p class="text-hint">4. Jemaat yang boleh hadir <b>berusia 13 s/d 59 tahun</b>.</p>
    <p class="text-hint">5. <b>Kuota</b> kehadiran <b>210 tempat duduk</b> ( Ruang Utama no. 1 - 102,
        Serambi 103 - 139, balkon 140 - 210 ).</p>
    <p class="text-hint">6. Hadir 15 Menit sebelum ibadah dimulai.</p>
</div>
<?php /**PATH /var/www/html/Project/Project1/resources/views/layouts/user/sidebar.blade.php ENDPATH**/ ?>