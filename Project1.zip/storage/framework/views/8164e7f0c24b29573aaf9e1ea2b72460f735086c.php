<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">

                        
                        <div class="card-header">
                            <div class="col-sm-12 col-md-6">
                                <h3>Edit</h3>
                            </div>
                        </div>

                        
                        <div class="card-body">
                            <form action="<?php echo e(route('worship.update', $item->id)); ?>" method="POST">
                                <?php echo method_field('PUT'); ?>
                                <?php echo csrf_field(); ?>
                                
                                <div class="form-group row">
                                    <label for="name" class="col-sm-2 col-form-label">Nama Ibadah</label>
                                    <div class="col-sm-4">
                                      <input type="text" name="name" value="<?php echo e($item->name); ?>" class="form-control">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="time" class="col-sm-2 col-form-label">Time</label>
                                    <div class="col-sm-4">
                                      <input type="text" placeholder="07:00" name="time" value="<?php echo e($item->time); ?>" class="form-control">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="date" class="col-sm-2 col-form-label">Tanggal</label>
                                    <div class="col-sm-4">
                                      <input type="date" name="date" value="<?php echo e($item->date); ?>" class="form-control">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="quota" class="col-sm-2 col-form-label">Quota</label>
                                    <div class="col-sm-4">
                                      <input type="number" name="quota" value="<?php echo e($item->quota); ?>" class="form-control">
                                    </div>
                                </div>

                                    <button type="submit" class="btn btn-primary float-right col-md-2">Ubah</button>

                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Project/Project1/resources/views/pages/worship/edit.blade.php ENDPATH**/ ?>