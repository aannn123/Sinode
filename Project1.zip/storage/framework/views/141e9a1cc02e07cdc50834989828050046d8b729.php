<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="<?php echo e(route('admin')); ?>">Admin SINODE</a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="<?php echo e(route('admin')); ?>">SINODE</a>
        </div>
        <ul class="sidebar-menu">
            

            <li class="menu-header">Dashboard</li>
            
            <li><a class="nav-link" href="<?php echo e(route('admin')); ?>"><i class="fas fa-th"></i> <span>Dashboard</span></a></li>
            
            <li class="nav-item dropdown">
                <a href="#" class="nav-link has-dropdown"><i class="fas fa-users"></i>
                    <span>Data Survey</span></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo e(route('memenuhi')); ?>">Memenuhi Syarat</a></li>
                    </ul>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo e(route('tidakMemenuhi')); ?>">Tidak Memenuhi Syarat</a></li>
                    </ul>
            </li>
            
            <li>
                <a href="<?php echo e(route('gereja.index')); ?>"><i class="fas fa-church"></i>
                    <span>Gereja</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('worship.index')); ?>"><i class="fas fa-pray"></i>
                    <span>Worship</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('age.index')); ?>"><i class="fas fa-user"></i>
                    <span>Age</span>
                </a>
            </li>
            <li class="nav-item dropdown">
                <a href="#" class="nav-link has-dropdown"><i class="fas fa-chair"></i>
                    <span>Kursi</span></a>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo e(route('kursi')); ?>">Kursi Gereja</a></li>
                </ul>
                
            </li>
            
            

        </ul>

        
    </aside>
</div><?php /**PATH /var/www/html/Project/Project1/resources/views/layouts/admin/sidebar.blade.php ENDPATH**/ ?>